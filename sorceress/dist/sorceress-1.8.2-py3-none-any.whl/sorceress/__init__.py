__version__ = '1.8.2'
from sorceress import *
