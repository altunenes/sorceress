__version__ = '1.8.8'
from sorceress import *
